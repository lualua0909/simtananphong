<?php
/**
 * The landing page for our theme
 *
 * Template Name: Đăng ký chính chủ
 */

if (!defined('ABSPATH')):
	exit; // Exit if accessed directly.
endif;

// Initialize N Framework.
_n_framework();

