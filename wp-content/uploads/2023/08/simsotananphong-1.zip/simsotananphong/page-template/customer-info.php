<?php
/**
 * The landing page for our theme
 *
 * Template Name: Thông tin khách hàng
 */

if (!defined('ABSPATH')):
	exit; // Exit if accessed directly.
endif;

// Initialize N Framework.
_n_framework();

