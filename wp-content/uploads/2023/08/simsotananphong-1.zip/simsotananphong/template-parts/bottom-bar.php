<?php

$general_settings = get_field('_theme_general_settings', 'option');
$bottom_bar       = $general_settings['_bottom_bar'];

?>

<section class="bottom-bar-wrapper">
	<div class="button-bar-buttons">
		<a href="<?= $bottom_bar['_phone'] ?>">
			<img src="<?= get_theme_file_uri('assets/images/call-2.png') ?>" alt="Gọi điện"><br>
			<span class="text">Gọi điện</span>
		</a>
		<a href="<?= $bottom_bar['_tiktok'] ?>">
			<img src="<?= get_theme_file_uri('assets/images/tiktok.png') ?>" alt="Tiktok"><br>
			<span class="text">Tiktok</span>
		</a>
		<a href="<?= $bottom_bar['_zalo'] ?>">
			<img src="<?= get_theme_file_uri('assets/images/zalo.png') ?>" alt="Chat Zalo"><br>
			<span class="text">Chat Zalo</span>
		</a>
		<a href="<?= $bottom_bar['_facebook'] ?>">
			<img src="<?= get_theme_file_uri('assets/images/fb.png') ?>" alt="Chat Facebook"><br>
			<span class="text">Chat Facebook</span>
		</a>
	</div>
</section>
