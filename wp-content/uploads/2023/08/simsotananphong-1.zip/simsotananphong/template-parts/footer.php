<?php

$footer_settings = get_field('_theme_footer_settings', 'option');
$branch          = $footer_settings['_branch'];

?>

<div class="footer">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-12">
				<h5 class="company-name"><?= $footer_settings['_text_1'] ?></h5>
				<p class="tax"><?= $footer_settings['_text_2'] ?></p>
				<p class="tax"><?= $footer_settings['_text_3'] ?></p>
				<p class="tax"><?= $footer_settings['_text_4'] ?></p>
			</div>

			<?php if ($branch):
				foreach ($branch as $branch_key => $branch_item): ?>
					<div class="col-lg-4 col-md-6 footer-widget">
						<h6 class="widget-title"><?= $branch_item['_title'] ?></h6>
						<?php if ($branch_item['_info']): ?>
							<ul class="info">
								<?php foreach ($branch_item['_info'] as $branch_info): ?>
									<li>
									<span class="icon">
										<?= wp_get_attachment_image($branch_info['_icon']) ?>
									</span>
										<?= $branch_info['_text'] ?>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				<?php endforeach;
			endif; ?>
		</div>
	</div>
</div>
