<div class="theme-loader-wrapper">
	<div class="theme-loader"></div>
</div>
