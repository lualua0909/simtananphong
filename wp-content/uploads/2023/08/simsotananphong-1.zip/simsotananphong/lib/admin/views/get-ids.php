<div class="wrap">
	<h2>Fix dạng số (Chỉ dành cho Developer)</h2>
	<form method="POST" enctype="multipart/form-data" id="get-ids-form">
		<p class="submit">
			<input type="submit" name="submit" value="Chạy" class="button button-primary">
		</p>
	</form>
</div>
